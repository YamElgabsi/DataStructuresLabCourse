package il.ac.telhai.ds.trees;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.rmi.RemoteException;

public class ExpressionTree extends FullBinaryTree<String>
{
    public ExpressionTree(String value) {
        super(value);
    }

    public ExpressionTree(String value, BinaryTree<String> left, BinaryTree<String> right) {
        super(value, left, right);
    }

    /*
     * Read the stream tokenizer until EOF assuming and construct
     *  the expression tree corresponding to it.
     * The input contains a prefix expression.
     */

    public static ExpressionTree createTree(StreamTokenizer tokenizer) throws IOException {
        ExpressionTree tree = null;
        tokenizer.nextToken();
        if (tokenizer.ttype == StreamTokenizer.TT_EOF || tokenizer.ttype == StreamTokenizer.TT_EOL)
            return tree;
        char c = (char) tokenizer.ttype;
        if (tokenizer.ttype == StreamTokenizer.TT_NUMBER) {
            tree = new ExpressionTree(Integer.toString((int)tokenizer.nval));
            return tree;
        }
        if (c != '*' && c != '/' && c != '+' && c != '-')
            throw new RuntimeException("Wrong operator!");
        tree = new ExpressionTree(String.valueOf(c), createTree(tokenizer), createTree(tokenizer));
        return tree;
    }

    /*
     * Returns the infix expression corresponding to the current tree (*)
     */
    public String infix() {
        return inOrder();
    }

    /*
     * Returns the prefix expression corresponding to the current tree (*)
     */
    public String prefix() {
        return preOrder(" ", " ");
    }

    /*
     * Evaluates the expression corresponding to the current tree
     * and returns its value
     */
    public double evaluate() {
        String val = getValue();
        ExpressionTree left = (ExpressionTree)getLeft();
        ExpressionTree right = (ExpressionTree)getRight();
        if (val.equals("/"))
            return left.evaluate() / right.evaluate();
        if (val.equals("*"))
            return left.evaluate() * right.evaluate();
        if (val.equals("+"))
            return left.evaluate() + right.evaluate();
        if (val.equals("-"))
            return left.evaluate() - right.evaluate();
        return Double.parseDouble(val);
        }
}



