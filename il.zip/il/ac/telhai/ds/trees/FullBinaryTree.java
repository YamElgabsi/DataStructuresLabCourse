package il.ac.telhai.ds.trees;

public class FullBinaryTree<T> extends BinaryTree<T>
{
    public FullBinaryTree(T value) {
        super(value);
    }

    public FullBinaryTree(T value, BinaryTree<T> left, BinaryTree<T> right) {
        super(value, left, right);
        if ( (left != null && right == null) || (left == null && right != null))
            throw new RuntimeException("not full binary tree");
    }

    @Override
    public void setLeft(BinaryTreeI<T> left) {
        if (left == null && getLeft() == null)
            return;
        if ((left == null && getLeft() != null) || (left != null && getLeft() == null))
            throw new RuntimeException("cant work");

        if (left.getClass() != this.getClass())
            throw new RuntimeException("cant work");
        super.setLeft(left);
    }

    @Override
    public void setRight(BinaryTreeI<T> right) {
        if (right == null && getRight() == null)
            return;

        if ((right == null && getRight() != null) || (right != null && getRight() == null))
            throw new RuntimeException("cant work");

        if (right.getClass() != this.getClass())
            throw new RuntimeException("cant work");
        super.setRight(right);
    }

    @Override
    public String inOrder() {
        String tree = "";
        if (this.getLeft() != null) {
            tree += "(";
            tree += this.getLeft().inOrder();
            tree += " ";
        }
        tree += getValue().toString();
        if (this.getRight() != null) {
            tree += " ";
            tree += this.getRight().inOrder();
            tree += ")";
        }
        return tree;
    }
}
