package il.ac.telhai.ds.trees;



public class BinaryTree<T> implements BinaryTreeI<T>
{
    private T value;
    private BinaryTreeI<T> left;
    private BinaryTreeI<T> right;

    public BinaryTree(T value){
        this.value = value;
        this.left = null;
        this.right = null;
    }

    public BinaryTree(T value, BinaryTreeI<T> left, BinaryTreeI<T> right){
        this.value = value;
        this.left = left;
        this.right = right;
    }

    @Override
    public BinaryTreeI<T> getLeft() {
        return this.left;
    }

    @Override
    public BinaryTreeI<T> getRight() {
        return this.right;
    }

    @Override
    public T getValue() {
        return this.value;
    }

    @Override
    public void setValue(T value)
    {
        this.value = value;
    }

    @Override
    public void setLeft(BinaryTreeI<T> left)
    {
        this.left = left;
    }

    @Override
    public void setRight(BinaryTreeI<T> right) {
        this.right = right;
    }

    @Override
    public boolean isLeaf()
    {
        return (left == null && right == null);
    }

    @Override
    public int height()
    {
        int counter = 0;
        if (isLeaf())
            return 0;
        if (this.left != null && this.right == null)
            counter += this.left.height() + 1;
        if (this.right != null && this.left == null)
            counter += this.right.height() + 1;
        if (this.left != null && this.right != null)
            counter += Integer.max(this.left.height() , this.right.height()) + 1;
        return counter;
    }

    @Override
    public int size()
    {
        int counter = 1;
        if (this.left != null)
            counter += this.left.size();
        if (this.right != null)
            counter += this.right.size();
        return counter;
    }

    @Override
    public void clear()
    {
        this.value = null;
        this.right = null;
        this.left = null;
    }

    @Override
    public String preOrder()
    {
        return preOrder(" ", " ");
    }

    @Override
    public String preOrder(String separationBeforeVal, String separationAfterVal)
    {
        String tree =separationBeforeVal+value.toString()+separationAfterVal;

        if (this.left != null){
            tree += this.left.preOrder(separationBeforeVal , separationAfterVal);

        }
        if (this.right != null){
            tree += this.right.preOrder(separationBeforeVal , separationAfterVal);
        }

        return tree;
    }

    @Override
    public String inOrder()
    {
        return inOrder(" ", " ");
    }

    @Override
    public String inOrder(String separationBeforeVal, String separationAfterVal) {
        String tree = "";
        if (this.left != null)
            tree += this.left.inOrder(separationBeforeVal,separationAfterVal);
        tree += separationBeforeVal;
        tree += value.toString();
        tree += separationAfterVal;
        if (this.right != null)
            tree += this.right.inOrder(separationBeforeVal,separationAfterVal);
        return tree;
    }

    @Override
    public String postOrder() {
        return postOrder(" ", " ");

    }

    @Override
    public String postOrder(String separationBeforeVal, String separationAfterVal) {
        String tree = "";
        if (this.left != null)
            tree += this.left.postOrder(separationBeforeVal,separationAfterVal);
        if (this.right != null)
            tree += this.right.postOrder(separationBeforeVal,separationAfterVal);
        tree += separationBeforeVal;
        tree += this.value.toString();
        tree += separationAfterVal;
        return tree;
    }
}
