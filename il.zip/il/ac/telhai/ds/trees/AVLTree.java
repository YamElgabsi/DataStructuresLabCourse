package il.ac.telhai.ds.trees;

import java.util.LinkedList;
import java.util.Stack;

public class AVLTree <T extends Comparable<T>>
{
    private T val;
    private AVLTree <T> left;
    private AVLTree <T> right;
    private int height;

    public AVLTree(T value)
    {
        this.val = value;
        this.left = null;
        this.right = null;
        this.height = 0;
    }

    public int getBF(){
        int rightH = (right == null) ? -1 : right.height;
        int leftH = (left == null) ? -1 : left.height;

        return leftH-rightH;
    }

    private void updateHeight() {
        if (this.left == null && this.right == null)
        {
            this.height = 0;
            return;
        }
        if (this.left == null)
        {
            this.height = right.height+1;
            return;
        }
        if (this.right == null)
        {
            this.height = left.height+1;
            return;
        }
        this.height = Math.max(this.left.height , this.right.height) +1;
    }

    //add the value to the tree, and return the updated root of the tree.


    public AVLTree<T> add(T value) {

        AVLTree<T> newNode = new AVLTree<T>(value);

        if (value.compareTo(this.getValue()) == 0)
            throw new RuntimeException("already exist");

        if (value.compareTo(this.getValue()) > 0)
        {
            if (this.right == null)
                this.right = newNode;
            else
                this.right = right.add(value);
        }
        else
        {
            if (this.left == null)
                this.left = newNode;
            else
                this.left = left.add(value);
        }

        this.updateHeight();

        //left
        if (this.getBF() == 2)
        {
            //right
            if (left.getBF() == -1)
            {
                AVLTree<T> temp = left;
                this.left = temp.right;
                temp.right = left.left;
                left.left = temp;

                temp.updateHeight();
                left.updateHeight();
                this.updateHeight();
            }
            //left
            if (left.getBF() == 1)
            {
                AVLTree<T> temp = left;
                this.left = temp.right;
                temp.right = this;

                this.updateHeight();
                temp.updateHeight();

                return temp;
            }
        }
        //right
        if (this.getBF() == -2)
        {
            //left
            if (right.getBF() == 1)
            {
                AVLTree<T> temp = right;
                right = temp.left;
                temp.left = right.right;
                right.right = temp;

                temp.updateHeight();
                right.updateHeight();
                this.updateHeight();
            }
            if (right.getBF() == -1)
            {
                AVLTree<T> temp = right;
                this.right = temp.left;
                temp.left = this;

                this.updateHeight();
                temp.updateHeight();

                return temp;
            }
        }
        return this;
    }

    //return the value in this node
    public T getValue()
    {
        return this.val;
    }

    //return the left subTree of this node
    public AVLTree<T> getLeft()
    {
        return this.left;
    }

    //return the right subTree of this node
    public AVLTree<T> getRight()
    {
        return this.right;
    }
}


