package il.ac.telhai.ds.trees;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class BinarySearchTree<T extends Comparable<T>> extends BinaryTree<T> {

	public BinarySearchTree(T value, BinarySearchTree<T> left, BinarySearchTree<T> right) {
		super(value, left, right);

		if (left != null) {
			if (left.getValue().compareTo(this.getValue()) >= 0)
				throw new RuntimeException("invalid left");
		}

		if (right != null) {
			if (right.getValue().compareTo(this.getValue()) <= 0)
				throw new RuntimeException("invalid right");
		}


	}

	public BinarySearchTree(T value) {
		super(value);
	}

	;

	/**
	 * Adds the object value to the tree as a leaf according to the parameter. If
	 * the object was in the tree before, then a RuntimeException is thrown.
	 *
	 * @param val
	 */
	public void add(T val) {
		if (val.compareTo(this.getValue()) == 0)
			throw new RuntimeException("already exist");

		if (val.compareTo(this.getValue()) < 0) {
			if (this.getOriginalL() == null) {
				this.setLeft(new BinarySearchTree<T>(val));
				return;
			}
			((BinarySearchTree<T>)super.getLeft()).add(val);
			return;
		}
		if (this.getOriginalR() == null) {
			this.setRight(new BinarySearchTree<T>(val));
			return;
		}
		((BinarySearchTree<T>)super.getRight()).add(val);
		return;
	}

	/**
	 * Looks for an object which is equal to the parameter.
	 *
	 * @param val: the object to be looked for in the tree
	 * @return true if the tree contains this object. Otherwise, return false.
	 */
	public boolean contains(T val) {
		if (val.compareTo(this.getValue()) == 0)
			return true;

		if (val.compareTo(this.getValue()) < 0) {
			if (this.getLeft() == null)
				return false;
			return this.getLeft().contains(val);
		}
		if (this.getRight() == null)
			return false;
		return this.getRight().contains(val);
	}

	/**
	 * Looks for the minimal object in the tree, which is greater than or equal to
	 * the parameter.
	 *
	 * @param val: the object to be looked for in the tree
	 * @return a reference to the found object.
	 */
	public T findGE(T val) {

		if (contains(val))
			return val;

		add(val);
		if (returnSec(this , val) == null)
			return null;

		T s = returnSec(this , val).getValue();
		remove(val);
		return s;


	}

	/**
	 * Looks for the minimal object in the tree, which is smaller than or equal to
	 * the parameter.
	 *
	 * @param val: the object to be looked for in the tree
	 * @return a reference to the found object.
	 */
	public T findLE(T val) {
		if (contains(val))
			return val;
		BinarySearchTree<T> temp = this;
		while (temp.getLeft() != null){
			temp = temp.getLeft();
		}
		if (temp.getValue().compareTo(val) > 0)
			return null;



		BinarySearchTree<T> temp1 = this;
		BinarySearchTree<T> temp2 = this;

		Stack<BinarySearchTree<T>> fathers = new Stack<BinarySearchTree<T>>();

		while (!temp1.isLeaf()) {
			if (val.compareTo(temp1.getValue()) > 0) {
				if (temp1.getRight() == null)
					break;
				fathers.push(temp1);
				temp1 = temp1.getRight();
				continue;
			}
			if (temp1.getLeft() != null){
				fathers.push(temp1);
				temp1 = temp1.getLeft();
			}


		}
		if (fathers.isEmpty()){
			if (val.compareTo(temp1.getValue()) > 0)
				return this.getValue();
			return null;
		}
		temp2 = temp1;
		temp1 = fathers.pop();

		if (temp1.getRight() != null) {
			if (temp1.getRight().getValue() == temp2.getValue())
				return temp2.getValue();
		}
		if (temp1.getLeft() != null){
			if (temp1.getLeft().getValue() == temp2.getValue())
				return temp2.getValue();
		}

		while (fathers.isEmpty()){
			temp2 = temp1;
			temp1 = fathers.pop();
			if (temp1.getRight() != null) {
				if (temp1.getRight().getValue() == temp2.getValue())
					return temp1.getValue();
			}
			if (temp1.getLeft() != null){
				if (temp1.getLeft().getValue() == temp2.getValue())
					return temp1.getValue();
			}
		}
		if (temp1.getRight() != null) {
			if (temp1.getRight().getValue() == temp2.getValue())
				return temp1.getValue();
		}
		if (temp1.getLeft() != null) {
			if (temp1.getLeft().getValue() == temp2.getValue())
				return temp1.getValue();
		}
		return temp1.getValue();

	}
	public ArrayList<BinarySearchTree<T>> inOrderToList(BinarySearchTree<T> tree) // create sorted array using inOrder - helper to returnSec()
	{
		ArrayList<BinarySearchTree<T>> inOrderList = new ArrayList<BinarySearchTree<T>>();
		ArrayList<BinarySearchTree<T>> left;
		ArrayList<BinarySearchTree<T>> right;

		if (tree == null)
			return inOrderList;

		left = inOrderToList(tree.getLeft());
		right = inOrderToList(tree.getRight());
		for (BinarySearchTree<T> node: left) {
			inOrderList.add(node);
		}

		inOrderList.add(tree);

		for (BinarySearchTree<T> node: right) {
			inOrderList.add(node);
		}
		return  inOrderList;
	}


	private BinarySearchTree<T> returnSec(BinarySearchTree<T> tree, T val) // returning sucsessor
	{
		if (!tree.contains(val))
			throw new RuntimeException(val.toString() + "not exist");

		ArrayList<BinarySearchTree<T>> inOrderList = inOrderToList(tree);

		if (val.compareTo(inOrderList.get(inOrderList.size()-1).getValue()) == 0)
		{
			return null;
		}

		for (int i = 0; i< inOrderList.size(); i++ )
		{
			if (inOrderList.get(i).getValue().compareTo(val) == 0)
				return inOrderList.get(i+1);
		}
		return null;
	}


	/**
	 * Removes the object in the tree which is equal to the parameter. If the object
	 * was found but the tree contains only one element, it want be removed and a
	 * run-time exception will be thrown. Nothing is done if node found
	 *
	 * @param val: the object to be looked for in the tree
	 * @return True, if the element was removed. Otherwise false.
	 */
	public boolean remove(T val) {
		if (!contains(val))
			return false;
		BinarySearchTree<T> prev = this;
		BinarySearchTree<T> temp = this;
		while(!(temp.getValue().compareTo(val) == 0))
		{
			prev = temp;
			if (val.compareTo(temp.getValue()) > 0)
			{
				temp = temp.getOriginalR();
			}
			else
			{
				temp = temp.getOriginalL();
			}
		}
		//Is a leaf
		if (temp.isLeaf())
		{
			if (prev.getLeft() != null) {
				if (prev.getLeft().getValue().compareTo(temp.getValue()) == 0) {
					prev.setLeft(null);
					return true;
				}
			}
			if (prev.getRight() != null) {
				if (prev.getRight().getValue().compareTo(temp.getValue()) == 0) {
					prev.setRight(null);
					return true;
				}
			}
		}
		//Has only right son
		if(temp.getRight() != null && temp.getLeft() == null)
		{
			if (prev.getLeft().getValue().compareTo(temp.getValue()) == 0)
			{
				prev.setLeft(temp.getRight());
				return true;
			}
			if(prev.getRight().getValue().compareTo(temp.getValue()) == 0)
			{
				prev.setRight(temp.getRight());
				return true;
			}
		}
		//Has only left son
		if(temp.getRight() == null && temp.getLeft() != null) {
			if (prev.getLeft().getValue().compareTo(temp.getValue()) == 0) {
				prev.setLeft(temp.getLeft());
				return true;
			}
			if (prev.getRight().getValue().compareTo(temp.getValue()) == 0) {
				prev.setRight(temp.getLeft());
				return true;
			}
		}
		//If he has two sons
		if(temp.getLeft() != null && temp.getRight() != null)
		{
			T newVal = returnSec(this , temp.getValue()).getValue();
			this.remove(newVal);
			temp.setValue(newVal);
			return true;
		}
		return false;

	}

	@Override
	public BinarySearchTree<T> getLeft() {
		if (super.getLeft() == null)
			return null;
		BinaryTreeI<T> ret = super.getLeft();
		if(ret.getRight() != null)
		{
			if(ret.getRight().getValue().compareTo(this.getValue()) > 0)
			{
				return new BinarySearchTree<T>(super.getLeft().getValue(), (BinarySearchTree<T>) super.getLeft().getLeft(), null);
			}
		}


		return new BinarySearchTree<T>(super.getLeft().getValue(), (BinarySearchTree<T>) super.getLeft().getLeft(), (BinarySearchTree<T>) super.getLeft().getRight());
	}

	private BinarySearchTree<T> getOriginalR()
	{
		return (BinarySearchTree<T>) super.getRight();
	}
	private BinarySearchTree<T> getOriginalL()
	{
		return (BinarySearchTree<T>) super.getLeft();
	}

	@Override
	public BinarySearchTree<T> getRight() {
		if (super.getRight() == null)
			return null;

		BinaryTreeI<T> ret = super.getRight();
		if(ret.getLeft() != null)
		{
			if(ret.getLeft().getValue().compareTo(this.getValue()) < 0)
			{
				return new BinarySearchTree<T>(super.getLeft().getValue(), null, (BinarySearchTree<T>) super.getLeft().getLeft());
			}
		}

		return new BinarySearchTree<T>(super.getRight().getValue(), (BinarySearchTree<T>) super.getRight().getLeft(), (BinarySearchTree<T>) super.getRight().getRight());
	}

	@Override
	public void setLeft(BinaryTreeI<T> left) {
		if (left != null)
		{
			if(this.getClass() != left.getClass())
			{
				throw new RuntimeException();
			}
			if (this.getValue().compareTo(left.getValue()) < 0) {
				throw new RuntimeException("bigger than the head");
			}
		}
		super.setLeft(left);
	}

	@Override
	public void setRight(BinaryTreeI<T> right) {
		if (right != null)
		{
			if(this.getClass() != right.getClass())
			{
				throw new RuntimeException();
			}
			if (this.getValue().compareTo(right.getValue()) > 0)
				throw new RuntimeException("smaller to the head");
		}
		super.setRight(right);
	}

	@Override
	public void setValue(T value) {
		if (getLeft() != null)
		{
			if (value.compareTo(getLeft().getValue()) < 0) {
				throw new RuntimeException("bigger than expected");
			}
		}
		if (getRight() != null)
		{
			if (value.compareTo(getRight().getValue()) > 0) {
				throw new RuntimeException("smaller than expected");
			}
		}
		super.setValue(value);
	}
}