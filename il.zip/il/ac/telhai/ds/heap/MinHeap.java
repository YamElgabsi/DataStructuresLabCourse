package il.ac.telhai.ds.heap;


public class MinHeap<T extends Comparable<T>> {
	private int maxHeapSize;
	private int counter;
	private T[] data;


	@SuppressWarnings({"unchecked","rawtypes"})
	public MinHeap(int length) {
		int size = 1;
		while(true)
		{
			if (length <= Math.pow(2 , size))
				break;
			size *= 2;
		}
		maxHeapSize = (int) Math.pow(2 , size);
		counter = 0;

		data = (T[]) new Comparable[maxHeapSize+1];
	}
	@SuppressWarnings({"unchecked","rawtypes"})
	public MinHeap(T[] arr) {
		maxHeapSize = (int) log2(arr.length) + 1;
		counter = arr.length;
		data = (T[]) new Comparable[((int) Math.pow(2,maxHeapSize)) + 1];
		for (int i = counter; i>0; i--)	data[i] = arr[i-1];
		for (int i = counter; i>0; i--)	heapIfyUp(i);
		heapIfyUp(counter);
	}

	public boolean isFull() {
		return counter == maxHeapSize;
	}

	public boolean isEmpty() {
		return counter == 0;
	}
	public double log2(double a)	{
		return Math.log(a) / Math.log(2);
	}
	private void heapIfyUp(int index)
	{
		while(index != 1)
		{
			int mom = index/2;
			if (data[mom] == null) return;
			if (data[mom].compareTo(data[index]) > 0)
			{
				T temp = data[mom];
				data[mom] = data[index];
				data[index] = temp;
			}
			index = mom;
		}
	}

	public void insert(T element) {
		data[++counter] = element;
		heapIfyUp(counter);
	}

	public T getMin() {
		if (counter == 0)
			throw new RuntimeException("ERROR: the heap is empty");
		return data[1];
	}
	private void heapIfyDown(int index)
	{
		if(index > this.counter)	return;
		int leftDaughterIndex = 2 * index;
		int rightDaughterIndex = (2 * index) + 1;
		T leftDaughter = null, rightDaughter = null;
		if(leftDaughterIndex <= this.counter)	leftDaughter = data[leftDaughterIndex];
		if(rightDaughterIndex <= this.counter)	rightDaughter = data[rightDaughterIndex];

		if(rightDaughter == null && leftDaughter == null)	return;
		T temp;
		if (rightDaughter == null){
			if (data[index].compareTo(leftDaughter) > 0){
				temp = data[index];
				data[index] = leftDaughter;
				data[leftDaughterIndex] = temp;
				heapIfyDown(leftDaughterIndex);
			}
			return;
		}
		if (leftDaughter == null){
			if (data[index].compareTo(rightDaughter) > 0){
				temp = data[index];
				data[index] = rightDaughter;
				data[rightDaughterIndex] = temp;
				heapIfyDown(rightDaughterIndex);
			}
			return;
		}
		int min;
		if (data[leftDaughterIndex].compareTo(data[rightDaughterIndex]) > 0)	min = rightDaughterIndex;
		else min = leftDaughterIndex;
		if (data[index].compareTo(data[min]) > 0){
			temp = data[index];
			data[index] = data[min];
			data[min] = temp;
			heapIfyDown(min);
		}
	}
	public T deleteMin() {
		if (counter == 0)
			return null;
		T temp = data[1];
		T lastElem = data[counter--];
		int i = 1;
		int minIdx = 1;
		while (2*i < log2(counter))
		{
			T min;
			if (data[2*i].compareTo(data[(2*i) + 1]) < 0) {
				min = data[2 * i];
				minIdx = 2*i;
			}
			else {
				min = data[(2 * i) + 1];
				minIdx = (2 * i) + 1;
			}

			data [i] = min;
			i = minIdx;
		}
		data[minIdx] = lastElem;
		for (int j = 1; j <= counter ; j++) heapIfyDown(j);
		return temp;
	}

	/**
	 * return a string represents the heap. The order of the elements are according
	 * to The string starts with "[", ends with "]", and the values are seperated
	 * with a comma
	 */
	public String toString() {
		String toReturn = "[";
		for (int i = 1; i <= counter; i++) {
			if (i != 1)
				toReturn += ",";
			toReturn += data[i].toString();
		}
		toReturn += "]";
		return toReturn;
	}
}
