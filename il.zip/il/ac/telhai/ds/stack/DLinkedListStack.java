package il.ac.telhai.ds.stack;

public class DLinkedListStack <T> implements Stack<T>
{
    private DLinkedList <T> stack;
    private int counter;

    public DLinkedListStack() {
        this.stack = new DLinkedList<T>();
        counter = 0;
    }

    @Override
    public void push(T t)
    {
        this.stack.goToEnd();
        this.stack.insert(t);
        counter++;
    }

    @Override
    public T pop()
    {
        if (stack.isEmpty())
            return null;
        this.stack.goToEnd();
        counter--;
        return this.stack.remove();

    }

    @Override
    public T top()
    {
        if (stack.isEmpty())
            return null;
        this.stack.goToEnd();
        return this.stack.getCursor();

    }

    @Override
    public boolean isEmpty()
    {
        return this.stack.isEmpty();
    }

    @Override
    public String toString() {
        this.stack.goToEnd();
        StringBuilder toReturn = new StringBuilder();
        toReturn.append('[');

        for (int i = counter; i > 0; i--)
        {
            toReturn.append(this.stack.getCursor());
            if (i != 1)
                toReturn.append(", ");
            this.stack.getPrev();
        }
        toReturn.append(']');
        return toReturn.toString();
    }
}
