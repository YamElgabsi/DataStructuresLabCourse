package il.ac.telhai.ds.hash;

import il.ac.telhai.ds.linkedlist.DLinkedList;


public class HashTable<V> {
	public static final int DEF_MAX_HASH_SIZE = 10;
	private DLinkedList<V> [] table;
	int counter;


	/**
	 * c'tor
	 * construct a hash-table of max-size "DEF_MAX_HASH_SIZE".
	 */
	@SuppressWarnings({"unchecked","rawtypes"})
	public HashTable() {
		table = new DLinkedList[DEF_MAX_HASH_SIZE];
		for (int i = 0; i < table.length; i++) {
			table[i] = new DLinkedList<V>();

		}
		counter = 0;
	}
	
	/**
	 * construct a hash-table of size 'hashSize'.
	 * @param hashSize, the size of the constructed hash-table.
	 */
	@SuppressWarnings({"unchecked","rawtypes"})
	public HashTable (int hashSize) {
		table = new DLinkedList[hashSize];
		for (int i = 0; i < table.length; i++) {
			table[i] = new DLinkedList<V>();

		}
		counter = 0;
	}
	
	/**
	 * @param val
	 * @return true if the hash-table contains val, otherwise return false
	 */
	public boolean contains(V val) {
		int hash = Math.abs(val.hashCode() % this.table.length);
		DLinkedList<V> list = this.table[hash];
			if (list.isEmpty())
				return false;
			list.goToBeginning();

			while(true)
			{
				V value = list.getCursor();
				if (value.equals(val))
					return true;
				if (!list.hasNext())
					break;
				list.getNext();
			}


		return false;
	}

	/**
	 * Add val to the hash-table.
	 * 
	 * @param val
	 * @return If the val has already exist in the the hash-table, it will not be
	 *         added again. Return true if the val was added successfully. Otherwise
	 *         return false.
	 */
	public boolean add(V val) {
		if (this.contains(val))
			return false;
		int hash = Math.abs(val.hashCode() % this.table.length);
		this.table[hash].insert(val);
		counter++;
		return true;
	}

	/**
	 * Remove val from the hash-table.
	 * 
	 * @param val
	 * @return Return true if the val was removed successfully. Otherwise return
	 *         false.
	 */
	public boolean remove(V val) {
		if (!this.contains(val))
			return false;
		int hash = Math.abs(val.hashCode() % this.table.length);

		if (this.table[hash].remove(val) == null)
			return false;
		counter--;
		return true;


	}

	/**
	 * clear al the data in the hash-table
	 */
	@SuppressWarnings({"unchecked","rawtypes"})
	public void clear() {
		table = new DLinkedList[this.table.length];
		counter = 0;
	}

	/**
	 * @return true if the hase-table is empty, otherwise return false.
	 */
	public boolean isEmpty() {
		return counter == 0;
	}
}