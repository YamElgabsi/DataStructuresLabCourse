package il.ac.telhai.ds.hash;

public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
