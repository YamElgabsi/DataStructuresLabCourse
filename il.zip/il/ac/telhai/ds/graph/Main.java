package il.ac.telhai.ds.graph;

public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
