package il.ac.telhai.ds.graph;

import java.util.*;

public class Graph<V extends Comparable<V>, E> implements IGraph<V , E>{
    private class Edge{
        private V from;
        private V to;
        private E type;

        public Edge(V from, V to, E type) {
            this.from = from;
            this.to = to;
            this.type = type;
        }


        public boolean isWeighted() {
            if(type instanceof Number)
                return true;
            if(type instanceof Weighted)
                return true;
            return false;
        }
    }

    private TreeMap<V,LinkedList<Edge>> graph;
    private int numOfNodes;

    public Graph()
    {
        graph = new TreeMap<>();
        numOfNodes = 0;
    }


    @Override
    public void add(V v) {
        if(graph.containsKey(v))
            throw new RuntimeException(v.toString() + "already exist");
        graph.put(v , new LinkedList<>());
        numOfNodes++;
    }

    private Edge searchEdge(V u, V v )
    {
        for (Edge edge : graph.get(u))
        {
            if (edge.to.equals(v))
                return edge;
        }
        return null;
    }
    @Override
    public E getEdge(V u, V v) {
        if (!graph.containsKey(u))
            return null;
        if (!graph.containsKey(v))
            return null;
        Edge edge = searchEdge(u , v);
        if (edge == null)
            return null;
        return edge.type;
    }

    @Override
    public E putEdge(V u, V v, E edgeLabel) {
        if (!graph.containsKey(u))
            add(u);
        if (!graph.containsKey(u))
            add(v);
        Edge edge = searchEdge(u , v);
        if (edge != null)
        {
            edge.type = edgeLabel;
            searchEdge(v , u).type = edgeLabel;
            return edge.type;
        }
        graph.get(u).add(new Edge(u , v, edgeLabel));
        graph.get(v).add(new Edge(v , u, edgeLabel));
        return edgeLabel;

    }

    @Override
    public boolean containsVertex(V v) {
        return graph.containsKey(v);
    }

    @Override
    public void removeVertex(V v) {
        if (!graph.containsKey(v))
            return;

        for (Edge edge : graph.get(v)) {
            for (int i = 0; i < graph.get(edge.to).size(); i++) {
                if (graph.get(edge.to).get(i).to.equals(edge.from))
                {
                    graph.get(edge.to).remove(i);
                    break;
                }
            }

        }
        graph.remove(v);
        numOfNodes--;
    }

    @Override
    public E removeEdge(V u, V v) {
        if (!graph.containsKey(u))
            throw new RuntimeException(u.toString() + "not exist");
        if (!graph.containsKey(v))
            throw new RuntimeException(v.toString() + "not exist");

        Edge edge_u = searchEdge(u , v);

        if (edge_u == null)
            return null;

        Edge edge_v = searchEdge(v , u);
        graph.get(v).remove(edge_v);
        graph.get(u).remove(edge_u);
        return edge_u.type;
    }

    @Override
    public double getWeight(V u, V v) {
        Edge edge = searchEdge(u,v);
        if (edge == null)
            return 0;
        if(edge.type instanceof Number)
            return (Double) edge.type;
        try {
            Weighted w = (Weighted) edge.type;
            return w.getWeight();
        }
        catch (Exception e){
            throw new RuntimeException("should not work");
        }
    }

    @Override
    public String toStringExtended() {
        String str = "";
        for (int i = 0; i < numOfNodes; i++) {
            str += graph.keySet().toArray()[i].toString();
            str += ":";
            LinkedList<Edge> lst = graph.get(graph.keySet().toArray()[i]);
            for (int j = 0; j < lst.size(); j++) {
                if (j != 0)
                    str += ",";
                V small, big;
                if (lst.get(j).from.toString().compareTo(lst.get(j).to.toString()) > 0){
                    big = lst.get(j).from;
                    small = lst.get(j).to;
                }
                else {
                    small = lst.get(j).from;
                    big = lst.get(j).to;
                }
                str+= "{" + small.toString() +
                        "," + big.toString() +
                        "}";
                try {
                    if (getWeight(lst.get(j).from , lst.get(j).to) != 0)
                        str += "(" + (getWeight(lst.get(j).from , lst.get(j).to)) + ")";
                }
                catch (Exception e){}

            }
            if (i != numOfNodes - 1)
                str += "\n";
        }
        return str;
    }

    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < numOfNodes; i++) {
            if (i != 0)
                str += ",";
            str += graph.keySet().toArray()[i].toString();
        }
        return str;
    }

    @Override
    public boolean areAdjacent(V u, V v) {
        if (!graph.containsKey(u))
            return false;
        if (!graph.containsKey(u))
            return false;

        if (searchEdge(u , v) == null)
            return false;
        return true;
    }
    private double minWeight(V v , HashSet<V> visited )
    {
        V min = null;
        LinkedList<Edge> lst = graph.get(v);
        int i = 0;
        for (; i < lst.size(); i++) {
            if (visited.contains(lst.get(i).to))
                continue;
            if (min == null)
                min = lst.get(i).to;
            else
            {
                if (getWeight(v , lst.get(i).to) < getWeight(v , min))
                    min = lst.get(i).to;
            }
            if (min == null)
                return -1;
        }
        return getWeight(v , min);

    }
    public TreeMap<V, Double> distancesFrom(V v)
    {
        TreeMap<V, Double> tree = new TreeMap<V, Double>();
        for (V node : graph.keySet()) {
            if (node.compareTo(v) == 0)
                tree.put(node , 0.0);
            else
                tree.put(node , Double.POSITIVE_INFINITY);
        }
        PriorityQueue<V> pq = new PriorityQueue<>();
        HashSet<V> visited = new HashSet<>();
        pq.add(v);

        while (!pq.isEmpty())
        {
            V temp = pq.remove();
            LinkedList<Edge> lst = graph.get(temp);
            double min = minWeight(temp , visited);

            for (int i = 0; i < lst.size(); i++)
            {
                if (tree.get(lst.get(i).to) > tree.get(temp) + getWeight(temp , lst.get(i).to))
                    tree.put(lst.get(i).to , tree.get(temp) + getWeight(temp , lst.get(i).to));
                if ((min == getWeight(temp , lst.get(i).to)) && !visited.contains(lst.get(i).to) && !pq.contains(lst.get(i).to) )
                {
                    pq.add(lst.get(i).to);
                    pq.add(temp);
                }

            }
            visited.add(temp);
        }
        Object[] keys = tree.keySet().toArray();
        for (Object temp : keys) {
            if (tree.get(temp) == Double.POSITIVE_INFINITY)
                tree.remove(temp);
        }
        return tree;
    }
}
